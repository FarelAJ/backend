const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');

const app = express();
app.use(bodyParser.json());

const data = JSON.parse(fs.readFileSync('data.json'));

app.get('/customers', (req, res) => {
    res.json(data.customers);
});

app.get('/customers/:id', (req, res) => {
    const customerId = parseInt(req.params.id);
    const customer = data.customers.find(cust => cust.customer_id === customerId);
    if (customer) {
        res.json(customer);
    } else {
        res.status(404).json({ message: 'Customer not found' });
    }
});

app.post('/customers', (req, res) => {
    const newCustomer = req.body;
    data.customers.push(newCustomer);
    fs.writeFileSync('data.json', JSON.stringify(data, null, 2));
    res.status(201).json(newCustomer);
});

app.put('/customers/:id', (req, res) => {
    const customerId = parseInt(req.params.id);
    const updatedCustomer = req.body;
    data.customers = data.customers.map(customer => {
        if (customer.customer_id === customerId) {
            return { ...customer, ...updatedCustomer };
        }
        return customer;
    });
    fs.writeFileSync('data.json', JSON.stringify(data, null, 2));
    res.json(updatedCustomer);
});

app.delete('/customers/:id', (req, res) => {
    const customerId = parseInt(req.params.id);
    data.customers = data.customers.filter(customer => customer.customer_id !== customerId);
    fs.writeFileSync('data.json', JSON.stringify(data, null, 2));
    res.json({ message: 'Customer deleted successfully' });
});

app.get('/orders', (req, res) => {
    res.json(data.orders);
});

app.get('/orders/:id', (req, res) => {
    const orderId = parseInt(req.params.id);
    const order = data.orders.find(order => order.order_id === orderId);
    if (order) {
        res.json(order);
    } else {
        res.status(404).json({ message: 'Order not found' });
    }
});

app.post('/orders', (req, res) => {
    const newOrder = req.body;
    data.orders.push(newOrder);
    fs.writeFileSync('data.json', JSON.stringify(data, null, 2));
    res.status(201).json(newOrder);
});

app.put('/orders/:id', (req, res) => {
    const orderId = parseInt(req.params.id);
    const updatedOrder = req.body;
    data.orders = data.orders.map(order => {
        if (order.order_id === orderId) {
            return { ...order, ...updatedOrder };
        }
        return order;
    });
    fs.writeFileSync('data.json', JSON.stringify(data, null, 2));
    res.json(updatedOrder);
});

app.delete('/orders/:id', (req, res) => {
    const orderId = parseInt(req.params.id);
    data.orders = data.orders.filter(order => order.order_id !== orderId);
    fs.writeFileSync('data.json', JSON.stringify(data, null, 2));
    res.json({ message: 'Order deleted successfully' });
});

app.listen(3000, () => {
    console.log('Server started on port 3000');
});
