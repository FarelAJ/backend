const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');

const app = express();
const port = 3000;

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'restoran_db'
});

db.connect((err) => {
    if (err) {
        throw err;
    }
    console.log('MySQL Connected...');
});

app.use(bodyParser.json());

app.get('/customers', (req, res) => {
    const sql = 'SELECT * FROM customers';
    db.query(sql, (err, results) => {
        if (err) throw err;
        res.json(results);
    });
});

app.get('/customers/:id', (req, res) => {
    const { id } = req.params;
    const sql = 'SELECT * FROM customers WHERE id = ?';
    db.query(sql, id, (err, results) => {
        if (err) throw err;
        res.json(results[0]);
    });
});

app.post('/customers', (req, res) => {
    const { name, email } = req.body;
    const sql = 'INSERT INTO customers (name, email) VALUES (?, ?)';
    db.query(sql, [name, email], (err, result) => {
        if (err) throw err;
        res.send('Customer added...');
    });
});

app.put('/customers/:id', (req, res) => {
    const { name, email } = req.body;
    const { id } = req.params;
    const sql = 'UPDATE customers SET name = ?, email = ? WHERE id = ?';
    db.query(sql, [name, email, id], (err, result) => {
        if (err) throw err;
        res.send('Customer details updated...');
    });
});

app.delete('/customers/:id', (req, res) => {
    const { id } = req.params;
    const sql = 'DELETE FROM customers WHERE id = ?';
    db.query(sql, id, (err, result) => {
        if (err) throw err;
        res.send('Customer deleted...');
    });
});

app.get('/orders', (req, res) => {
    const sql = 'SELECT *, SUM(total_amount) AS total_amount FROM orders';
    db.query(sql, (err, results) => {
        if (err) throw err;
        res.json(results);
    });
});

app.get('/orders/:id', (req, res) => {
    const { id } = req.params;
    const sql = 'SELECT orders.*, customers.name AS customer_name FROM orders INNER JOIN customers ON orders.customer_id = customers.id WHERE orders.id = ?';
    db.query(sql, id, (err, results) => {
        if (err) throw err;
        res.json(results[0]);
    });
});

app.post('/orders', (req, res) => {
    const { customer_id, total_amount } = req.body;
    const sql = 'INSERT INTO orders (customer_id, total_amount) VALUES (?, ?)';
    db.query(sql, [customer_id, total_amount], (err, result) => {
        if (err) throw err;
        res.send('Order added...');
    });
});

app.put('/orders/:id', (req, res) => {
    const { total_amount } = req.body;
    const { id } = req.params;
    const sql = 'UPDATE orders SET total_amount = ? WHERE id = ?';
    db.query(sql, [total_amount, id], (err, result) => {
        if (err) throw err;
        res.send('Order details updated...');
    });
});

app.delete('/orders/:id', (req, res) => {
    const { id } = req.params;
    const sql = 'DELETE FROM orders WHERE id = ?';
    db.query(sql, id, (err, result) => {
        if (err) throw err;
        res.send('Order deleted...');
    });
});

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
